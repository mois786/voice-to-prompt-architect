export default {
 async fetch(request, env) {
  const url = new URL(request.url);
  if (url.pathname.startsWith('/api/')) {
   if (request.method !== 'POST' || url.pathname !== '/api/proxy') return json({error:'Not found'},404);
   let body; try { body=await request.json(); } catch { return json({error:'Invalid JSON'},400); }
   const p=body.provider||{};
   if (!p.baseUrl || !p.key) return json({error:'Provider Base URL and API key are required'},400);
   let base; try { base=new URL(p.baseUrl); } catch { return json({error:'Invalid Base URL'},400); }
   if (!['https:'].includes(base.protocol)) return json({error:'Only HTTPS provider URLs are allowed'},400);
   const headers={'content-type':'application/json'};
   if (p.format==='anthropic') { headers['x-api-key']=p.key; headers['anthropic-version']='2023-06-01'; }
   else headers['authorization']=`Bearer ${p.key}`;
   try {
    let target, init;
    if(body.action==='models'){
      target=new URL(p.format==='anthropic'?'/v1/models':'/models',base);
      init={method:'GET',headers};
    } else if(body.action==='chat') {
      if(p.format==='anthropic'){
       target=new URL('/v1/messages',base);
       headers['anthropic-version']='2023-06-01';
       init={method:'POST',headers,body:JSON.stringify({model:body.model,max_tokens:4096,system:body.system,messages:[{role:'user',content:body.input}]})};
      } else {
       target=new URL('/chat/completions',base);
       init={method:'POST',headers,body:JSON.stringify({model:body.model,messages:[{role:'system',content:body.system},{role:'user',content:body.input}]})};
      }
    } else return json({error:'Unknown action'},400);
    const upstream=await fetch(target,init); const raw=await upstream.text(); let data; try{data=JSON.parse(raw)}catch{data={raw:raw.slice(0,1500)}}
    if(!upstream.ok) return json({error:data?.error?.message||data?.message||`Provider returned HTTP ${upstream.status}`,status:upstream.status},upstream.status);
    if(body.action==='models') return json(data);
    const text=data?.choices?.[0]?.message?.content || data?.content?.map(x=>x.text||'').join('\\n') || '';
    return json({text,usage:data.usage||null,raw:data});
   } catch(e){return json({error:e.message||'Upstream request failed'},502)}
  }
  return env.ASSETS.fetch(request);
 }
};
function json(data,status=200){return new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json','cache-control':'no-store'}})}
